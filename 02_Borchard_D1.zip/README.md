# PlayIt

# Playlist Sharing Web App

## Description
A web application that allows users to share and discover playlists. Built with React.

![alt text](frontend/public/assets/images/image.png)