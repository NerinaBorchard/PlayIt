import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';

ReactDOM.render(<App />, document.getElementById('root'));


// // src/index.js
// import React from 'react';
// import ReactDOM from 'react-dom';
// import SplashPage from './pages/SplashPage';

// // Render the SplashPage component in the root div
// ReactDOM.render(<SplashPage />, document.getElementById('root'));

